const pool = require('../db')

let User = function(data) {
    this.data = data
    this.erros = []
}

User.prototype.create = function() {

    const consulta = "INSERT INTO users(username, password) values($1, $2)";
    const values = [this.data.username, this.data.password];
    return new Promise((resolve, reject) => {
        pool.query(consulta, values, (error, results) =>{
        if(error) {
            reject ("Erro ao inserir usuário");
        } else {
            resolve("Usuário Inserido com sucesso");
        }
         });
    });
};

module.exports = User