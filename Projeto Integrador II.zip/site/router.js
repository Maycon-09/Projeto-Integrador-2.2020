const express = require('express')
const router = express.Router()

const userController = require('./controllers/userController')

///roteamento
router.get('/', userController.home)
router.get('/acess', userController.acess)
router.get('/login', userController.login)
router.get('/signUp', userController.registro)
router.post('/register', userController.save)

// jogo da memoria
router.get('/homeGame', userController.homeGame)
router.get('/jogoMemoria01', userController.memoria01)
router.get('/jogoMemoria02', userController.memoria02)
router.get('/jogoMemoria03', userController.memoria03)
router.get('/jogoMemoria04', userController.memoria04)

// Operação Soma
router.get('/homeGameSoma', userController.homeGameSoma)
router.get('/soma01', userController.soma01)
router.get('/soma02', userController.soma02)
module.exports = router;