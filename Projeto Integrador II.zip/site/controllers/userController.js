const User = require('../models/User')

exports.home = function (req, res){
    res.render('pages/home')
}

exports.acess = function (req, res) {
    res.render('pages/acess-game', {layout: 'pages/acess-game'})
}

// jogo da memoria
exports.homeGame = function (req, res) {
    res.render('pages/Jogo/home-game', {layout: 'pages/Jogo/home-game'})
} 
exports.memoria01 = function (req, res) {
    res.render('pages/Jogo/nivel01', {layout: 'pages/Jogo/nivel01'})
}
exports.memoria02 = function (req, res) {
    res.render('pages/Jogo/nivel02', {layout: 'pages/Jogo/nivel02'})
}
exports.memoria03 = function (req, res) {
    res.render('pages/Jogo/nivel03', {layout: 'pages/Jogo/nivel03'})
}
exports.memoria04 = function (req, res) {
    res.render('pages/Jogo/nivel04', {layout: 'pages/Jogo/nivel04'})
}

// operação soma
exports.homeGameSoma = function (req, res) {
    res.render('pages/operação-soma/home-game', {layout: 'pages/operação-soma/home-game'})
}
exports.soma01 = function (req, res) {
    res.render('pages/operação-soma/nivel 01', {layout: 'pages/operação-soma/nivel 01'})
}
exports.soma02 = function (req, res) {
    res.render('pages/operação-soma/nivel 02', {layout: 'pages/operação-soma/nivel 02'})
}


exports.login = function (req, res){
    res.render('pages/login', {layout: 'pages/login'})
}

exports.registro = function (req, res){
    res.render('pages/registrar', {layout: 'pages/registrar'})
}

exports.save = function (req, res) {
    let user = new User(req.body)
    user.create()
    .then(function (result){
        res.render("pages/home")
    }).catch(function(err){
        res.send(err)
    })
}