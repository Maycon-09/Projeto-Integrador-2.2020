let progress = "0%";

function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}

document.getElementById('lvl-01').onclick= ()=> {
  window.open('/jogoMemoria', 'jogoMemoria', 'resizable,height=1200,width=1400'); 
  return false;
}
document.getElementById('lvl-02').onclick= ()=> {
  window.open('/homeGame', 'home-game', 'resizable,height=1200,width=1400'); 
  return false;
}
document.getElementById('lvl-03').onclick= ()=> {
  window.open('/homeGameSoma', 'home-game', 'resizable,height=1200,width=1400'); 
  return false;
}
document.getElementById('lvl-04').onclick= ()=> {
  window.open('/jogoMemoria', 'jogoMemoria', 'resizable,height=1200,width=1400'); 
  return false;
}
document.getElementById('lvl-05').onclick= ()=> {
  window.open('/jogoMemoria', 'jogoMemoria', 'resizable,height=1200,width=1400'); 
  return false;
}
document.getElementById('lvl-06').onclick= ()=> {
  window.open('/jogoMemoria', 'jogoMemoria', 'resizable,height=1200,width=1400'); 
  return false;
}

/// Progress Bar

document.getElementById('progress-bar').style.width = progress;
document.getElementById('progress-bar').innerHTML = `<h6 id="bar">${progress}</h6>`;

