document.getElementById('button-play').onclick = () => {
    let url = ('/jogoMemoria01');
    window.open(url, "_self")
}
