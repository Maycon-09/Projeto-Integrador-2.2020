document.getElementById('button-play').onclick = () => {
    let url = ('/soma01');
    window.open(url, "_self")
}
